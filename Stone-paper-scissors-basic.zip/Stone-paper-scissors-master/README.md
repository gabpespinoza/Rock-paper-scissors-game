<div align="center">
      <h1> <img src="./src/assets/start_img.jpeg"><br/>Stone Paper Scissors</h1>
</div>

# Live Preview

[Demo](https://stone-papers-scissors.netlify.app/)

# Stone Paper Scissors

"Stone Paper Scissors" game built with React.js and framer motion and it is a PWA

# Tech which I have Used

![React](https://img.shields.io/badge/react-%2320232a.svg?style=for-the-badge&logo=react&logoColor=%2361DAFB)
![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white)
![FRAMER](https://img.shields.io/badge/Framer-a2e?style=for-the-badge&logo=framer)
![PWA](https://img.shields.io/badge/PWA-F6C915?style=for-the-badge&logo=pwa&logoColor=black)

## Follow the below instruction to run this project in your pc.👇

```
git clone https://github.com/Milan-960/Stone-paper-scissors.git
```

```
npm install
```

```
npm
```
