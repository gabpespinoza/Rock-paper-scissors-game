import Game from "./components/game";

const App = () => {
  return (
    <>
      <Game />
    </>
  );
};

export default App;
